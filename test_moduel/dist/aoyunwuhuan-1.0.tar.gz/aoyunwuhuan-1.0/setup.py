from distutils.core import setup

setup(
    name = 'aoyunwuhuan',
    version = '1.0',
    description = '奥运五环',
    author = 'gwq',
    author_email= '767107797@qq.com',
    py_modules = ['huahua.aoyunwuhuan']   # 要发布的模块
)